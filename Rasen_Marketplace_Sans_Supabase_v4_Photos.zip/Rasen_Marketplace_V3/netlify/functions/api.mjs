import { getStore } from '@netlify/blobs';

const LIMITS = {
  listings: { title: 75, body: 500 },
  journals: { title: 100, body: 2000 }
};

function response(statusCode, data) {
  return { statusCode, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, body: JSON.stringify(data) };
}
function clean(v, max) { return String(v ?? '').replace(/\u0000/g, '').trim().slice(0, max); }
function validPhone(v) { return !v || /^[+()\d\s.-]{7,40}$/.test(v); }

export const handler = async (event) => {
  const resource = event.queryStringParameters?.resource;
  if (!['listings', 'journals'].includes(resource)) return response(404, { error: 'Ressource inconnue.' });
  const store = getStore(`rasen-marketplace-${resource}`);
  const key = 'public-items-v1';
  try {
    if (event.httpMethod === 'GET') {
      const items = (await store.get(key, { type: 'json' })) || [];
      return response(200, { items: Array.isArray(items) ? items.slice(0, 300) : [] });
    }
    if (event.httpMethod !== 'POST') return response(405, { error: 'Méthode non autorisée.' });
    if (!event.body || event.body.length > 250000) return response(413, { error: 'Publication trop volumineuse. Réduis la taille de la photo et réessaie.' });
    if (event.headers?.['content-type'] && !event.headers['content-type'].toLowerCase().includes('application/json')) return response(415, { error: 'Le serveur attend des données JSON.' });
    let input;
    try { input = JSON.parse(event.body); } catch { return response(400, { error: 'Données invalides.' }); }
    const title = clean(input.title, LIMITS[resource].title);
    const body = clean(resource === 'listings' ? input.desc : input.body, LIMITS[resource].body);
    if (!title || !body) return response(400, { error: 'Le titre et le texte sont obligatoires.' });
    if (title.length < 3 || body.length < 3) return response(400, { error: 'Le titre et le texte doivent contenir au moins 3 caractères.' });
    const item = resource === 'listings'
      ? { id: Date.now() + Math.floor(Math.random() * 1000), type: input.type === 'need' ? 'need' : 'offer', cat: clean(input.cat, 30) || 'Autre', icon: clean(input.icon, 8) || '📌', title, desc: body, price: clean(input.price, 50) || 'À discuter', location: clean(input.location, 60), name: clean(input.name, 60), contact: clean(input.contact, 40), photo: (typeof input.photo === 'string' && input.photo.startsWith('data:image/jpeg;base64,') && input.photo.length <= 190000) ? input.photo : '', demo: false, createdAt: new Date().toISOString().slice(0,10) }
      : { id: Date.now() + Math.floor(Math.random() * 1000), author: clean(input.author, 60), category: clean(input.category, 30) || 'Autre', title, body, contact: clean(input.contact, 40), createdAt: new Date().toISOString().slice(0,10) };
    if (resource === 'listings' && (!item.location || !item.name || !item.contact || !validPhone(item.contact))) return response(400, { error: 'Vérifie le lieu, le nom et le numéro de contact.' });
    if (resource === 'journals' && !item.author) return response(400, { error: 'Le nom public est obligatoire.' });
    if (!validPhone(item.contact)) return response(400, { error: 'Le format du numéro de téléphone semble invalide.' });
    const current = (await store.get(key, { type: 'json' })) || [];
    const items = Array.isArray(current) ? current : [];
    items.unshift(item);
    await store.setJSON(key, items.slice(0, 300));
    return response(201, { item });
  } catch (error) {
    console.error('Rasen Marketplace API error', error);
    return response(500, { error: 'Erreur du stockage. Réessaie plus tard.' });
  }
};
